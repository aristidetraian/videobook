ls -1v *.avi > vidfile.txt
awk -F ' '  '{ print "file " $1 }' vidfile.txt > newvideo.txt
ffmpeg -f concat -safe 0 -i newvideo.txt -b:a 192k -c copy output.avi
ffmpeg -y -i output.avi -filter_complex loop=loop=1 -max_muxing_queue_size 9999 fout.avi
