# encoding: utf-8
import string
import os
import urllib2

def rff(fileinput):
   #this is a read from file function since it is getting a bit obsufcated to use open file
   try:
       str_file=open(fileinput,"r")
   except ValueError:
       return "Can not open file"
   try:
       readreturn=str_file.read()
   except ValueError:
       return "can not read the file after open"
   try:
       str_file.close()
   except ValueError:
       return "can not close the fiel"
   return readreturn

def wfo(fileinput,text):
   #this is a open and write from file function since it is getting a bit obsufcated to use open file
   try:
       str_file=open(fileinput,"w")
   except ValueError:
       return "Can not open file"
   try:
       readreturn=str_file.write(text)
   except ValueError:
       return "can not write the file after open"
   try:
       str_file.close()
   except ValueError:
       return "can not close the fiel"
   return 0

def wfa(fileinput,text):
   #this is a append file function since it is getting a bit obsufcated to use open file
   try:
       str_file=open(fileinput,"a")
   except ValueError:
       return "Can not open file"
   try:
       readreturn=str_file.write(text)
   except ValueError:
       return "can not write the file after open"
   try:
       str_file.close()
   except ValueError:
       return "can not close the fiel"
   return 0

def readdict(dicttext,intentention,linesplit):
   """ this funtion reads the dictionarry in an array that is outputed """
   string1=rff(dicttext)
   array1=[["",""]]
   limit=0
   word=""
   lines=string1.split(linesplit)
   #print(lines)
   for line in lines:
      array1+=[line.split(intentention)]
   return array1[1:-1]


def addtxtif(line,dictarray):
   """ This function adds string to string if it finds match"""
   i=0
   print(line)
   print(dictarray)
   while i>=0:
      i=line.find(dictarray[0],i)
      if i>=0:
         line=line[:i]+dictarray[1]+line[i:]
         i=i+len(dictarray[0]+dictarray[1])
         #print(i)
      else:
         break
      print('we are in the while loop')
      
      #print(i)
   
   return line      

def addtxtif1(line,dictarray):
   """ This function replace string to string if it finds match"""
   i=0
   print(line)
   print(dictarray)
   while i>=0:
      i=line.find(dictarray[0],i)
      if i>=0:
         print(i,line,line[:i],line[i+len(dictarray[0]):])
         line=line[:i]+dictarray[1]+line[i+len(dictarray[0]):]
         i=i+len(dictarray[1])
         #print(i)
      else:
         break
      print('we are in the while loop')
      
      #print(i)
   
   return line   

def replacedictnospace(dictarray,inputtext,outputtext):
   """ this fuction replace all the words no space needed at begining needed in a text fiel from dictionary"""
   string0=rff(inputtext)
   wfo(outputtext,'')
   prevstring=''
   i=0
   try:
      with open(inputtext) as infile:
         for line in infile:
            i=0
            line1=line
            for i in range(len(dictarray)):
               line1=addtxtif(line1,dictarray[i])
               #i+=1
               #print(i,dictarray[i])
               #print('this is in nospace')
               #print(line1)
            if prevstring=='\n':
               wfa(outputtext, ' \\ \\newline \n'+ line1)
            else:
               wfa(outputtext, line1)
            prevstring=line[1]
   except ValueError:
      return 'could not open file one line at the time'
   return 0


def replacedictnospace1(dictarray,inputtext,outputtext):
   """ this fuction replace all the words no space needed at begining needed in a text fiel from dictionary with replacemt"""
   string0=rff(inputtext)
   wfo(outputtext,'')
   prevstring=''
   i=0
   try:
      with open(inputtext) as infile:
         for line in infile:
            i=0
            line1=line
            for i in range(len(dictarray)):
               line1=addtxtif1(line1,dictarray[i])
               #i+=1
               #print(i,dictarray[i])
               #print('this is in nospace')
               #print(line1)
            if prevstring=='\n':
               wfa(outputtext, ' \\ \\newline \n'+ line1)
            else:
               wfa(outputtext, line1)
            #print(line,len(line))
            prevstring=line[1]

   except ValueError:
      return 'could not open file one line at the time'
   return 0
   

def main():
   """this is the main fuction where we can also test stuff"""

   #print(readdict("dict.txt"," "))

   #print(readdict("dict.txt","=",'\n'))
   #replacedictnospace(readdict("dict.txt","=",'\n'),"0.txt","d0.txt")
   print(readdict("dict.txt","=",'\n'))
   replacedictnospace1(readdict("dict.txt","=",'\n'),"0.txt","d0.txt")
   
   
   return 0


#calling the main function
if __name__ == '__main__':
   main()



